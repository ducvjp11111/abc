CREATE DATABASE FAS

CREATE TABLE Traince(
	traince_id INT  AUTO_INCREMENT NOT NULL,
	`account` VARCHAR(32) UNIQUE NOT NULL ,
	full_name VARCHAR(100) NOT NULL,
	gender BIT DEFAULT NULL,
	birth_date DATE,
	phone_number VARCHAR(10),
	gpa NCHAR(10),
	`status` VARCHAR(10) DEFAULT 'active',
	
	PRIMARY KEY(traince_id)
)

