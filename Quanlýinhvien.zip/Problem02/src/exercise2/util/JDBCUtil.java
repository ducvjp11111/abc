package exercise2.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCUtil {

	public static Connection connection = null;

	public static Connection getConnection() {
		if (connection == null) {
			try {
				String username = "root";
				String password = "123456";
				String url = "jdbc:mysql://localhost:3306/fas";

				connection = DriverManager.getConnection(url, username, password);

			} catch (SQLException e) {

				e.printStackTrace();
			}

		}

		return connection;
	}
}
