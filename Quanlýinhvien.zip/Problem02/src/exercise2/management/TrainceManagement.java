package exercise2.management;

import java.util.List;
import java.util.Scanner;

import exercise2.dao.TrainceDao;
import exercise2.dao.TrainceDaoImpl;
import exercise2.entities.Traince;

public class TrainceManagement {

	static final int SAVE = 1;
	static final int UPDATE = 2;
	static final int DELETE = 3;
	static final int FINDINCOMPLETE = 4;
	static final int FINDEXCELLENT = 5;

	public static Traince product = null;
	private static TrainceDao trainceDao = new TrainceDaoImpl();


	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		do {
			menu();

			int choise = scanner.nextInt();
			switch (choise) {
			case SAVE:

				trainceDao.save(product);

				break;
			case UPDATE:

				trainceDao.update(product);

				break;
			case DELETE:

				trainceDao.delete();
				break;
			case FINDINCOMPLETE:
				try {

					List<Traince> products = trainceDao.findIncompleteTraince();
					for (Traince product : products) {
						System.out.println(product);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case FINDEXCELLENT:
				try {
					List<Traince> products = trainceDao.findExcellentTraince();
					for (Traince product : products) {
						System.out.println(product);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			default:
				scanner.close();
				System.exit(0);
				break;
			}
		} while (true);

	}

	public static void menu() {
		System.out.println("=======================================================");
		System.out.println();
		System.out.println("                          FA System                        ");
		System.out.println();
		System.out.println("=======================================================");
		System.out.println("\t1. Create Traince.................");
		System.out.println("\t2. Update Traince.................");
		System.out.println("\t3. Remove a specific Traince.................");
		System.out.println("\t4. Report incomplete Training................");
		System.out.println("\t5. List Excellent Trainces..............");
		System.out.println("\t6. Exit............................");
		System.out.println("Your choice...");
	}
}
