package exercise2.entities;

import java.io.Serializable;
import java.util.Scanner;

public class Traince implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String accuont;
	private String name;
	private int gender;
	private String birth_date;
	private String phone_number;
	private String gpa;
	private String status;

	public Traince() {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccuont() {
		return accuont;
	}

	public void setAccuont(String accuont) {
		this.accuont = accuont;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getGender() {
		return gender;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public String getBirth_date() {
		return birth_date;
	}

	public void setBirth_date(String birth_date) {
		this.birth_date = birth_date;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getGpa() {
		return gpa;
	}

	public void setGpa(String gpa) {
		this.gpa = gpa;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Product [id=" + this.id + ", account=" + this.accuont + ", full_name=" + this.name + ", gender="
				+ (this.gender == 1 ? "male" : "famale") + ", birth_date=" + this.birth_date + ", gpa=" + this.gpa
				+ ", status=" + this.status + "]";
	}

	public void input() {
		try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("Enter account :");
			this.accuont = scanner.nextLine();
			System.out.println("Enter full name :");
			this.name = scanner.nextLine();
			System.out.println("Enter gender :");
			this.gender = scanner.nextInt();
			scanner.nextLine();
			System.out.println("Enter birthdate :");
			this.birth_date = scanner.nextLine();
			System.out.println("Enter phone number :");
			this.phone_number = scanner.nextLine();
			System.out.println("Enter gpa :");
			this.gpa = scanner.nextLine();
			System.out.println("Enter status :");
			this.status = scanner.nextLine();
		}

	}

}
