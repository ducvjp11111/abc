package exercise2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import exercise2.entities.Traince;
import exercise2.util.JDBCUtil;

public class TrainceDaoImpl implements TrainceDao {

	public Connection conn = null;

	@Override
	public void save(Traince traince) {
		traince = new Traince();
		traince.input();
		try {

			conn = JDBCUtil.getConnection();
			String query = "insert into traince(account,full_name,gender,birth_date,phone_number, gpa, status ) values (?,?, ?, ?, ?,?,?)";

			PreparedStatement preparedStatement = conn.prepareStatement(query);
			preparedStatement.setString(1, traince.getAccuont());
			preparedStatement.setString(2, traince.getName());
			preparedStatement.setInt(3, traince.getGender());
			preparedStatement.setString(4, traince.getBirth_date());
			preparedStatement.setString(5, traince.getPhone_number());
			preparedStatement.setString(6, traince.getGpa());
			preparedStatement.setString(7, traince.getStatus());
			preparedStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update(Traince traince) {
		traince = new Traince();
		traince.input();
		try {
			// System.out.println("Create service done!");
			// JDBC
			conn = JDBCUtil.getConnection();
			String query = "update traince set full_name=?,gender=? ,birth_date=?,phone_number=?,gpa=?, status = where account= ?";

			PreparedStatement preparedStatement = conn.prepareStatement(query);

			preparedStatement.setString(1, traince.getName());
			preparedStatement.setInt(2, traince.getGender());
			preparedStatement.setString(3, traince.getBirth_date());
			preparedStatement.setString(4, traince.getPhone_number());
			preparedStatement.setString(5, traince.getGpa());
			preparedStatement.setString(6, traince.getStatus());
			preparedStatement.setString(7, traince.getAccuont());
			preparedStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void delete() {
		try {

			conn = JDBCUtil.getConnection();
			String query = "delete from traince where status = 'in-active' ";

			PreparedStatement preparedStatement = conn.prepareStatement(query);

			preparedStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public List<Traince> findIncompleteTraince() {
		String query = "select * from traince where gpa < 6 ";
		List<Traince> list = new ArrayList<>();
		Traince traince = null;

		try {
			conn = JDBCUtil.getConnection();
			PreparedStatement pre = conn.prepareStatement(query);
			ResultSet rs = pre.executeQuery();
			while (rs.next()) {
				traince = new Traince();
				traince.setId(rs.getInt("traince_id"));
				traince.setAccuont(rs.getString("account"));
				traince.setName(rs.getString("full_name"));
				traince.setGender(rs.getInt("gender"));
				traince.setBirth_date(rs.getString("birth_date"));
				traince.setGpa(rs.getString("gpa"));
				traince.setStatus(rs.getString("status"));
				list.add(traince);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return list;
	}

	@Override
	public List<Traince> findExcellentTraince() {
		String query = "select * from traince where gpa between 90 and 100 ";
		List<Traince> list = new ArrayList<>();
		Traince traince = null;

		try {
			conn = JDBCUtil.getConnection();
			PreparedStatement pre = conn.prepareStatement(query);
			ResultSet rs = pre.executeQuery();
			while (rs.next()) {
				traince = new Traince();
				traince.setId(rs.getInt("traince_id"));
				traince.setAccuont(rs.getString("account"));
				traince.setName(rs.getString("full_name"));
				traince.setGender(rs.getInt("gender"));
				traince.setBirth_date(rs.getString("birth_date"));
				traince.setGpa(rs.getString("gpa"));
				traince.setStatus(rs.getString("status"));
				list.add(traince);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return list;
	}


}
