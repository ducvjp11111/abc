package exercise2.dao;

import java.util.List;

import exercise2.entities.Traince;

public interface TrainceDao {

	public void save(Traince product);

	public void update(Traince product);

	public void delete();

	public List<Traince> findIncompleteTraince();

	public List<Traince> findExcellentTraince();
}
